package com.rk;

import java.util.List;
import java.io.IOException;
import java.util.ArrayList;

import org.springframework.context.annotation.PropertySource;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/my_app_url")

public class RestAPI {

	@RequestMapping(method = RequestMethod.POST) 
		
		public @ResponseBody FirstJson sayHello(@RequestBody List<FirstJson> example) {
		  for (FirstJson firstJson : example) {
			  System.out.println(firstJson.getJournalEntryId()+""+firstJson.getLedgerEntryId());
		  }
		
		return new FirstJson();
	}
	}

	
	
	/*public @ResponseBody Example sayHello(@RequestBody String example) {
		ObjectMapper obj = new ObjectMapper();
		
		try{
			
		try {
			
			Example readValue  = obj.readValue(example, Example.class);
			System.out.println(readValue.getInvoiceId());
			

			@SuppressWarnings("unchecked")
			List<Example> readValue = obj.readValue(example, List.class);
			System.out.println(readValue);
		} catch (IOException e) {
               e.printStackTrace();
	}
		return new Example();
	}*/

