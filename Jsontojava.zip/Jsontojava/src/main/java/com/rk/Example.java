package com.rk;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "LineItemId",
    "UnitsChange",
    "LedgerEntryId",
    "JournalEntryId",
    "InvoiceId",
    "ShareId",
    "TransactionDate",
    "TransactionTypeId",
    "TransactionTypeName",
    "ValueChange"
})
public class Example {

    @JsonProperty("LineItemId")
    private long lineItemId;
    @JsonProperty("UnitsChange")
    private long unitsChange;
    @JsonProperty("LedgerEntryId")
    private long ledgerEntryId;
    @JsonProperty("JournalEntryId")
    private Object journalEntryId;
    @JsonProperty("InvoiceId")
    private long invoiceId;
    @JsonProperty("ShareId")
    private long shareId;
    @JsonProperty("TransactionDate")
    private String transactionDate;
    @JsonProperty("TransactionTypeId")
    private long transactionTypeId;
    @JsonProperty("TransactionTypeName")
    private String transactionTypeName;
    @JsonProperty("ValueChange")
    private Double valueChange;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("LineItemId")
    public long getLineItemId() {
        return lineItemId;
    }

    @JsonProperty("LineItemId")
    public void setLineItemId(long lineItemId) {
        this.lineItemId = lineItemId;
    }

    @JsonProperty("UnitsChange")
    public long getUnitsChange() {
        return unitsChange;
    }

    @JsonProperty("UnitsChange")
    public void setUnitsChange(long unitsChange) {
        this.unitsChange = unitsChange;
    }

    @JsonProperty("LedgerEntryId")
    public long getLedgerEntryId() {
        return ledgerEntryId;
    }

    @JsonProperty("LedgerEntryId")
    public void setLedgerEntryId(Integer ledgerEntryId) {
        this.ledgerEntryId = ledgerEntryId;
    }

    @JsonProperty("JournalEntryId")
    public Object getJournalEntryId() {
        return journalEntryId;
    }

    @JsonProperty("JournalEntryId")
    public void setJournalEntryId(Object journalEntryId) {
        this.journalEntryId = journalEntryId;
    }

    @JsonProperty("InvoiceId")
    public long getInvoiceId() {
        return invoiceId;
    }

    @JsonProperty("InvoiceId")
    public void setInvoiceId(Integer invoiceId) {
        this.invoiceId = invoiceId;
    }

    @JsonProperty("ShareId")
    public long getShareId() {
        return shareId;
    }

    @JsonProperty("ShareId")
    public void setShareId(Integer shareId) {
        this.shareId = shareId;
    }

    @JsonProperty("TransactionDate")
    public String getTransactionDate() {
        return transactionDate;
    }

    @JsonProperty("TransactionDate")
    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    @JsonProperty("TransactionTypeId")
    public long getTransactionTypeId() {
        return transactionTypeId;
    }

    @JsonProperty("TransactionTypeId")
    public void setTransactionTypeId(Integer transactionTypeId) {
        this.transactionTypeId = transactionTypeId;
    }

    @JsonProperty("TransactionTypeName")
    public String getTransactionTypeName() {
        return transactionTypeName;
    }

    @JsonProperty("TransactionTypeName")
    public void setTransactionTypeName(String transactionTypeName) {
        this.transactionTypeName = transactionTypeName;
    }

    @JsonProperty("ValueChange")
    public Double getValueChange() {
        return valueChange;
    }

    @JsonProperty("ValueChange")
    public void setValueChange(Double valueChange) {
        this.valueChange = valueChange;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}



